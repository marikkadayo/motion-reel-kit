"""モーショングラフィックス型の縦リールを spec.json から作る。
  python3 reel_kit.py info|measure|stills|render spec.json [出力の秒...]
素材は縦動画1本（言い直し込みでよい）。演出の位置は「顔を中央にズームした画」を前提に固定してある。
"""
import json, math, os, random, subprocess, sys, wave
from functools import lru_cache
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter

W, H, FPS = 1080, 1920, 30
NORM = f"scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H}"
CREAM, INK, GREEN = (248, 245, 239), (34, 30, 38), (46, 160, 104)

SPEC = json.load(open(sys.argv[2]))
BASE = os.path.dirname(os.path.abspath(sys.argv[2]))
P = lambda p: p if os.path.isabs(p) else os.path.join(BASE, p)
WORK = P("_work"); os.makedirs(WORK, exist_ok=True)
SRC, SPEED = P(SPEC["src"]), SPEC.get("speed", 1.1)
PINK = tuple(SPEC.get("accent", (247, 168, 207)))
CUTS = SPEC["cuts"]
SEG = [(c["in"], c["out"]) for c in CUTS]
NF = [round((b - a) / SPEED * FPS) for a, b in SEG]
T0 = [sum(NF[:i]) / FPS for i in range(len(NF))]
DUR = [n / FPS for n in NF]
TOTAL = sum(NF) / FPS


def zoom_of(c):
    """顔を左右中央に寄せ、机(desk_y より下)を入れない切り出し (幅, 高さ, x, y)。head=(頭のてっぺんy, 顔の中心x, 髪の幅)"""
    if "zoom" in c:
        return tuple(c["zoom"])
    if "head" not in c:
        return (W, H, 0, 0)
    top, cx, hw = c["head"]
    desk = SPEC.get("desk_y") or H
    z = min(max(540 / hw, 540 / min(cx, W - cx), H / desk, 1.0), 1.5, max(610 / hw, H / desk))
    cw, ch = W / z, H / z
    x0 = min(max(cx - cw / 2, 0), W - cw)
    target = 250 if c.get("fx") == "hook" else 540
    y0 = min(max(top - target / z, 0), desk - ch)
    return (int(cw) // 2 * 2, int(ch) // 2 * 2, int(x0), int(y0))


ZOOM = [zoom_of(c) for c in CUTS]
ot = lambda i, s: T0[i] + (s - SEG[i][0]) / SPEED     # 素材の秒 → 出力の秒
clamp = lambda v, a=0.0, b=1.0: max(a, min(b, v))
ease = lambda p: 1 - (1 - clamp(p)) ** 3


def pop(p):
    p = clamp(p)
    return 0 if p <= 0 else 1 + 2.70158 * (p - 1) ** 3 + 1.70158 * (p - 1) ** 2


# ---------- 描く道具 ----------
def _noto(weight):
    for d in ("/usr/share/fonts/opentype/noto/", "/usr/share/fonts/noto-cjk/", "/System/Library/Fonts/"):
        for n in (f"NotoSansCJK-{weight}.ttc", f"NotoSansCJKjp-{weight}.otf"):
            if os.path.exists(d + n):
                return d + n
    hira = {"Black": "W8", "Bold": "W6", "Medium": "W5", "Regular": "W3"}[weight]
    mac = f"/System/Library/Fonts/ヒラギノ角ゴシック {hira}.ttc"
    if os.path.exists(mac):
        return mac
    fc = subprocess.run(["fc-match", "-f", "%{file}", f"sans:lang=ja:weight={'bold' if weight in ('Black', 'Bold') else 'regular'}"], capture_output=True, text=True).stdout.strip()
    assert fc, "日本語フォントが見つからない。Noto Sans CJK を入れる（apt install fonts-noto-cjk）"
    return fc


@lru_cache(None)
def font(kind, size):
    if kind == "hand":
        hf = SPEC.get("hand_font")
        return ImageFont.truetype(P(hf), size) if hf else font("Bold", size)
    return ImageFont.truetype(_noto(kind), size, index=0)


@lru_cache(None)
def text_sprite(text, kind, size, fill=(255, 255, 255), shadow=0.55, blur=7, stroke=0):
    if kind == "hand" and stroke == 0 and SPEC.get("hand_font"):
        stroke, shadow = max(1, size // 34), max(shadow, 0.8)
    f = font(kind, size)
    l, t, r, b = f.getbbox(text, stroke_width=stroke)
    pad = blur * 3 + 4
    im = Image.new("RGBA", (r - l + pad * 2, b - t + pad * 2), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    if shadow:
        sh = (0, 0, 0, int(255 * shadow))
        d.text((pad - l, pad - t + 3), text, font=f, fill=sh, stroke_width=stroke + 1, stroke_fill=sh)
        im = im.filter(ImageFilter.GaussianBlur(blur))
        d = ImageDraw.Draw(im)
    d.text((pad - l, pad - t), text, font=f, fill=fill + (255,), stroke_width=stroke, stroke_fill=fill + (255,))
    return im


def fit(text, kind, size, maxw):
    while size > 20 and font(kind, size).getlength(text) > maxw:
        size -= 4
    return size


def put(cv, sp, cx, cy, scale=1.0, rot=0.0, alpha=1.0, anchor="c"):
    if alpha <= 0.01 or scale <= 0.01:
        return
    if scale != 1.0:
        sp = sp.resize((max(1, int(sp.width * scale)), max(1, int(sp.height * scale))), Image.LANCZOS)
    if rot:
        sp = sp.rotate(rot, resample=Image.BICUBIC, expand=True)
    if alpha < 1:
        sp = sp.copy()
        sp.putalpha(sp.getchannel("A").point(lambda v: int(v * alpha)))
    x = int(cx - sp.width / 2) if anchor == "c" else int(cx)
    y = int(cy - sp.height / 2)
    cv.alpha_composite(sp, (max(x, 0), max(y, 0)), (max(-x, 0), max(-y, 0)))


def shadowed(im, radius=18, off=8, op=0.35):
    pad = radius * 2
    sh = Image.new("RGBA", (im.width + pad * 2, im.height + pad * 2), (0, 0, 0, 0))
    sh.paste((0, 0, 0, int(255 * op)), (pad, pad + off), im.getchannel("A"))
    out = sh.filter(ImageFilter.GaussianBlur(radius / 2))
    out.alpha_composite(im, (pad, pad))
    return out


def rounded(w, h, r, fill):
    im = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    ImageDraw.Draw(im).rounded_rectangle((0, 0, w - 1, h - 1), r, fill=fill)
    return im


@lru_cache(None)
def thumb(path, w, border=0):
    """画像は元の縦横比のまま（切らない）"""
    im = Image.open(P(path)).convert("RGBA")
    im = im.resize((w, int(w * im.height / im.width)), Image.LANCZOS)
    if border:
        fr = Image.new("RGBA", (im.width + border * 2, im.height + border * 2), (255, 255, 255, 255))
        fr.paste(im, (border, border))
        im = fr
    return shadowed(im, 14, 6, 0.4)


@lru_cache(None)
def stock_card(path, w, label):
    im = Image.open(P(path)).convert("RGBA")
    s = min(im.size)
    im = im.crop(((im.width - s) // 2, (im.height - s) // 2, (im.width + s) // 2, (im.height + s) // 2)).resize((w, w), Image.LANCZOS)
    fr = Image.new("RGBA", (w + 14, w + 68), (255, 255, 255, 255))
    fr.paste(im, (7, 7))
    f = font("Bold", fit(label, "Bold", 30, w - 10))
    ImageDraw.Draw(fr).text(((fr.width - f.getlength(label)) / 2, w + 11), label, font=f, fill=INK + (255,))
    return shadowed(fr, 14, 6, 0.4)


@lru_cache(None)
def star(size, color=None):
    im = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    c = size / 2
    pts = [(c + c * (0.95 if k % 2 == 0 else 0.42) * math.cos(-math.pi / 2 + k * math.pi / 5),
            c + c * (0.95 if k % 2 == 0 else 0.42) * math.sin(-math.pi / 2 + k * math.pi / 5)) for k in range(10)]
    ImageDraw.Draw(im).polygon(pts, fill=(color or PINK) + (255,))
    return im.filter(ImageFilter.GaussianBlur(0.6))


@lru_cache(None)
def crayon():
    w, h = 250, 56
    im = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    d.polygon([(0, h / 2), (46, 10), (46, h - 10)], fill=(214, 132, 190))
    d.rounded_rectangle((44, 4, w - 1, h - 4), 8, fill=(236, 160, 214))
    d.rectangle((80, 4, 200, h - 4), fill=(246, 196, 228))
    for x in (86, 194):
        d.line((x, 4, x, h - 4), fill=(150, 90, 140), width=3)
    d.line((100, h / 2, 180, h / 2), fill=(150, 90, 140), width=2)
    return shadowed(im, 8, 4, 0.3)


@lru_cache(None)
def crayon_text(text, size):
    sp = text_sprite(text, "hand", size, (240, 166, 220), shadow=0.35, blur=5, stroke=3)
    n = np.random.RandomState(3).rand(sp.height // 3 + 1, sp.width // 3 + 1).repeat(3, 0).repeat(3, 1)[:sp.height, :sp.width]
    a = np.array(sp.getchannel("A")).astype(np.float32) * (0.72 + 0.28 * (n > 0.22))
    sp = sp.copy()
    sp.putalpha(Image.fromarray(a.astype(np.uint8)))
    return sp


@lru_cache(None)
def folder(part):
    """パステルのフォルダ（白いステッチとハート）。back=後ろの板 / front=手前のポケット"""
    S = 3
    w, h = 320 * S, 225 * S
    im = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    back, front, line = (244, 160, 198, 255), (252, 205, 226, 255), (255, 255, 255, 255)
    if part == "back":
        d.rounded_rectangle((0, 0, 140 * S, 70 * S), 20 * S, fill=back)
        d.rounded_rectangle((0, 30 * S, w - 1, h - 1), 24 * S, fill=back)
        return shadowed(im.resize((320, 225), Image.LANCZOS), 14, 8, 0.3)
    d.rounded_rectangle((0, 62 * S, w - 1, h - 1), 24 * S, fill=front)
    x0, y0, x1, y1 = 16 * S, 78 * S, w - 16 * S, h - 16 * S
    for x in range(x0 + 14 * S, x1 - 14 * S, 16 * S):
        d.line((x, y0, x + 8 * S, y0), fill=line, width=3 * S)
        d.line((x, y1, x + 8 * S, y1), fill=line, width=3 * S)
    for y in range(y0 + 12 * S, y1 - 12 * S, 16 * S):
        d.line((x0, y, x0, y + 8 * S), fill=line, width=3 * S)
        d.line((x1, y, x1, y + 8 * S), fill=line, width=3 * S)
    cx, cy, r = w // 2, 148 * S, 22 * S
    d.ellipse((cx - 2 * r, cy - r, cx, cy + r), fill=line)
    d.ellipse((cx, cy - r, cx + 2 * r, cy + r), fill=line)
    d.polygon([(cx - 2 * r + 3 * S, cy + 8 * S), (cx + 2 * r - 3 * S, cy + 8 * S), (cx, cy + 2.2 * r)], fill=line)
    return shadowed(im.resize((320, 225), Image.LANCZOS), 14, 8, 0.0)


@lru_cache(None)
def card(w, h, title):
    im = rounded(w, h, 34, CREAM + (240,))
    ImageDraw.Draw(im).text((40, 26), title, font=font("Bold", 38), fill=INK + (255,))
    return shadowed(im, 22, 10, 0.3)


def card_in(cv, title, lt, dur, w=840, h=262, y=372):
    """白いカードを上から出す。戻り値: (中身を描く透明の板, 描き終えたら呼ぶ関数)"""
    pin = ease(lt / 0.22)
    al = min(pin * 1.4, 1) * clamp((dur - lt) / 0.12)
    cy = y - (1 - pin) * 60
    put(cv, card(w, h, title), 520, cy, alpha=al)
    ov = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    return ov, ImageDraw.Draw(ov), lambda: put(cv, ov, 520, cy, alpha=al)


# ---------- 演出（fx）。lt=カット内の秒, d=カットの長さ, p=spec の p ----------
def fx_hook(cv, lt, d, p, i):
    """左に過去作のスクショが1枚ずつ、あごの下に3段タイトル"""
    out = clamp((d - lt) / 0.2)
    slots = [(152, 358, 152, -7), (212, 566, 150, 6), (152, 776, 152, -5), (210, 982, 150, 7)]
    for k, (path, (x, y, w, r)) in enumerate(zip(p.get("snaps", []), slots)):
        q = (lt - 0.08 - k * 0.13) / 0.25
        if q > 0:
            put(cv, thumb(path, w), x, y, scale=pop(q), rot=r, alpha=min(1, q * 3) * out)
    s1, s2, s3 = p["title"]
    n = int(clamp((lt - 0.12) / 0.5) * len(s1))
    z1 = fit(s1, "hand", 62, 760)
    if n:
        put(cv, text_sprite(s1[:n], "hand", z1), 540 - text_sprite(s1, "hand", z1).width / 2, 1112, alpha=out, anchor="l")
    q = (lt - 0.2) / 0.3
    if q > 0:
        put(cv, text_sprite(s2, "Black", fit(s2, "Black", 128, 700), blur=10), 540, 1206, scale=pop(q), alpha=min(1, q * 3) * out)
    q = (lt - 0.95) / 0.75
    if q > 0:
        z3 = fit(s3, "hand", 58, 760)
        cur = "|" if (int(lt * 4) % 2 == 0 or q < 1) else ""
        put(cv, text_sprite(s3[:int(clamp(q) * len(s3))] + cur, "hand", z3), 540 - text_sprite(s3 + "|", "hand", z3).width / 2, 1306, alpha=out, anchor="l")


def fx_crayon(cv, lt, d, p, i):
    """クレヨンで手書き文字が書かれていく（横幅は画面の約6割）"""
    out = clamp((d - lt) / 0.12)
    sp = crayon_text(p["text"], fit(p["text"], "hand", 186, 640))
    x0, y = 110, 335
    e = ease(lt / 0.45)
    wv = int(sp.width * e)
    if wv > 4:
        put(cv, sp.crop((0, 0, wv, sp.height)), x0, y, alpha=out, anchor="l")
    put(cv, crayon(), x0 + wv + 120, y - 66 + (math.sin(lt * 40) * 10 if e < 1 else 0), scale=1.35, rot=38, alpha=out)
    for k, (dx, dy, s) in enumerate([(30, -96, 58), (96, -30, 38)]):
        q = (lt - 0.45 - k * 0.08) / 0.2
        if q > 0:
            put(cv, star(s), x0 + sp.width + dx, y + dy, scale=pop(q), rot=15 * k, alpha=out)


def stock_fly(d):
    t = max(0.5, d - 0.64)
    return [t, t + 0.16, t + 0.32]


def fx_stock(cv, lt, d, p, i):
    """ラベル付きの写真3枚を見せてから、1枚ずつフォルダに入れる"""
    out = clamp((d - lt) / 0.12)
    fx, fy, fly = 800, 388, stock_fly(d)
    bump = sum(max(0, 1 - abs(lt - (tf + 0.28)) / 0.1) for tf in fly)
    fs, fa = 1.1 * pop(lt / 0.22) * (1 + 0.09 * bump), min(1, lt / 0.22 * 3) * out
    put(cv, folder("back"), fx, fy, scale=fs, alpha=fa)
    for k, ((path, label), (x, y, r)) in enumerate(zip(p["items"], [(172, 372, -6), (372, 356, 3), (572, 374, -4)])):
        q = (lt - 0.04 - k * 0.1) / 0.25
        e = clamp((lt - fly[k]) / 0.28)
        if q <= 0 or e >= 1:
            continue
        e = e * e * (3 - 2 * e)
        put(cv, stock_card(path, 215, label), x + (fx - x) * e, y + (fy - 20 - y) * e - 70 * math.sin(math.pi * e),
            scale=pop(q) * (1 - 0.7 * e), rot=r + 22 * e, alpha=out * (1 if e < 0.8 else (1 - e) / 0.2))
    put(cv, folder("front"), fx, fy, scale=fs, alpha=fa)


def fx_starlist(cv, lt, d, p, i):
    """左上に星つきの手書きリストが1行ずつ"""
    out = clamp((d - lt) / 0.12)
    x, y = 96, 262
    put(cv, text_sprite(p["title"], "Bold", 36), x, y, alpha=clamp(lt / 0.15) * out, anchor="l")
    for k, s in enumerate(p["items"][:3]):
        q = (lt - 0.12 - k * 0.24) / 0.2
        if q > 0:
            yy = y + 78 + k * 84
            put(cv, star(46), x + 24, yy, scale=pop(q), rot=-12, alpha=out)
            put(cv, text_sprite(s[:max(1, int(clamp(q) * len(s)))], "hand", 64), x + 66, yy, alpha=out, anchor="l")


def fx_mindmap(cv, lt, d, p, i):
    """上の黒いカードから、顔の左右の4枚へ線が伸びる"""
    out = clamp((d - lt) / 0.15)
    hub = (540, 290)
    nodes = [(path, x, y, lab, thumb(path, 124, border=5)) for (path, lab), (x, y) in zip(p["nodes"], [(138, 560), (888, 560), (138, 860), (888, 860)])]
    ov = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    od = ImageDraw.Draw(ov)
    for k, (_, x, y, lab, sp) in enumerate(nodes):
        e = ease((lt - 0.18 - k * 0.1) / 0.3)
        if e > 0:
            hh = sp.height - 56
            sx, sy = (hub[0], hub[1] + 52) if k < 2 else (nodes[k - 2][1], nodes[k - 2][2] + (nodes[k - 2][4].height - 56) / 2 + 62)
            top = y - hh / 2 - 6
            od.line((sx, sy, sx + (x - sx) * e, sy + (top - sy) * e), fill=(255, 255, 255, int(235 * out)), width=3)
    cv.alpha_composite(ov)
    for k, (_, x, y, lab, sp) in enumerate(nodes):
        q = (lt - 0.42 - k * 0.1) / 0.25
        if q > 0:
            put(cv, sp, x, y, scale=pop(q), alpha=min(1, q * 3) * out)
            put(cv, text_sprite(lab, "Bold", fit(lab, "Bold", 34, 170)), x, y + (sp.height - 56) / 2 + 34, alpha=clamp(q) * out)
    t = text_sprite(p["hub"], "Bold", 54, shadow=0)
    logo = p.get("logo")
    cw = t.width - 50 + (98 if logo else 0) + 56
    c = rounded(cw, 104, 28, (28, 26, 30, 245))
    if logo:
        c.alpha_composite(Image.open(P(logo)).convert("RGBA").resize((76, 76), Image.LANCZOS), (22, 14))
    c.alpha_composite(t, ((112 if logo else 28) - 25, (104 - t.height) // 2 - 2))
    q = lt / 0.25
    put(cv, shadowed(c, 14, 8, 0.4), hub[0], hub[1], scale=pop(q), alpha=min(1, q * 3) * out)


def fx_card_gap(cv, lt, d, p, i):
    """白いカード: 波形の無音が詰まり、秒数が 0.0s になる"""
    ov, od, done_draw = card_in(cv, p["title"], lt, d)
    e = ease((lt - 0.45) / 0.75)
    rnd, groups, gap = random.Random(5), [14, 12, 13, 10], 62 * (1 - e)
    bx = (840 - (sum(groups) * 11 + gap * 3)) / 2
    for gi, n in enumerate(groups):
        for _ in range(n):
            hgt = rnd.randint(14, 74)
            od.rounded_rectangle((bx, 132 - hgt / 2, bx + 6, 132 + hgt / 2), 3, fill=INK + (255,))
            bx += 11
        if gi < 3:
            if gap > 6:
                od.line((bx + 4, 132, bx + gap - 6, 132), fill=(190, 186, 180, 255), width=3)
            bx += gap
    fin = e > 0.985
    od.text((270, 196), p.get("label", "無音"), font=font("Medium", 30), fill=(120, 116, 112, 255))
    od.text((350, 180), f"{p.get('from', 3.2) * (1 - e):.1f}s" + (" ✓" if fin else ""), font=font("Black", 50), fill=(GREEN if fin else INK) + (255,))
    done_draw()


def fx_card_caption(cv, lt, d, p, i):
    """白いカード: 字幕が1語ずつ出て、書体の札が選ばれる"""
    ov, od, done_draw = card_in(cv, p["title"], lt, d)
    od.rounded_rectangle((36, 86, 804, 172), 18, fill=(52, 48, 54, 255))
    toks = p["tokens"]
    n = min(len(toks), 1 + int(lt / (d * 0.52) * (len(toks) - 1)))
    f = font("Bold", 46)
    tx = 420 - sum(f.getlength(t) for t in toks) / 2
    for k in range(n):
        od.text((tx, 100), toks[k], font=f, fill=(PINK if k == n - 1 else (255, 255, 255)) + (255,))
        tx += f.getlength(toks[k])
    sel = lt > 0.5
    f2 = font("Bold", 28)
    a_txt = p.get("font_a", "源ノ角ゴシック") + (" ✓" if sel else "")
    aw = f2.getlength(a_txt) + 44
    od.rounded_rectangle((410 - aw, 192, 410, 240), 24, fill=(PINK + (255,)) if sel else (232, 228, 222, 255), outline=(200, 110, 160, 255) if sel else None, width=2)
    od.text((432 - aw, 196), a_txt, font=f2, fill=INK + (255,))
    od.text((450, 194), p.get("font_b", "てがき文字"), font=font("hand", 32), fill=(110, 106, 104, 255))
    done_draw()


def fx_card_speed(cv, lt, d, p, i):
    """白いカード: 速さのつまみが動いて ×1.1 ✓"""
    ov, od, done_draw = card_in(cv, p["title"], lt, d)
    to = p.get("to", SPEED)
    e = ease((lt - 0.4) / 0.6)
    x0, x1, ty = 70, 520, 160
    kx = x0 + (x1 - x0) * (0.25 + 0.4 * e)
    od.rounded_rectangle((x0, ty - 6, x1, ty + 6), 6, fill=(216, 212, 206, 255))
    od.rounded_rectangle((x0, ty - 6, kx, ty + 6), 6, fill=PINK + (255,))
    od.ellipse((kx - 22, ty - 22, kx + 22, ty + 22), fill=(255, 255, 255, 255), outline=(200, 110, 160, 255), width=4)
    for k in range(3):
        od.text((x0 + (x1 - x0) * (0.25 + 0.4 * k) - 20, ty + 34), f"{1 + (to - 1) * k:.1f}", font=font("Medium", 26), fill=(130, 126, 122, 255))
    fin = e > 0.985
    od.text((580, 112), f"×{to:.1f} ✓" if fin else f"×{1 + (to - 1) * e:.2f}", font=font("Black", 64), fill=(GREEN if fin else INK) + (255,))
    done_draw()


def fx_window(cv, lt, d, p, i):
    """白い画面の小窓に動画が縮む。上に小さい語、下に太い語（時刻は素材の秒）"""
    frame = cv.copy()
    pout = ease((lt - (d - 0.22)) / 0.22)
    e = ease(lt / 0.3) * (1 - pout)
    full, src, dst = (0, 0, W, H), (0, 560, 1080, 1390), (230, 700, 850, 1176)
    s = [full[k] + (src[k] - full[k]) * e for k in range(4)]
    t = [full[k] + (dst[k] - full[k]) * e for k in range(4)]
    win = frame.crop(tuple(int(v) for v in s)).resize((int(t[2] - t[0]), int(t[3] - t[1])), Image.LANCZOS)
    bg = Image.new("RGBA", (W, H), (244, 242, 240, 255))
    if e < 1:
        bg = Image.blend(frame, bg, clamp(e * 2.2))
    bg.alpha_composite(shadowed(win.convert("RGBA"), 16, 8, 0.25 * e), (int(t[0]) - 32, int(t[1]) - 32))
    cv.paste(bg)
    if e > 0.9:
        f, tx = font("Regular", 46), 240
        for wd, st in p.get("small", []):
            put(cv, text_sprite(wd, "Regular", 46, INK, shadow=0), tx, 650, alpha=clamp((lt - (ot(i, st) - T0[i])) / 0.1) * (1 - pout), anchor="l")
            tx += f.getlength(wd) + 26
        wd, st = p["big"]
        q = (lt - (ot(i, st) - T0[i])) / 0.18
        if q > 0:
            put(cv, text_sprite(wd, "Black", fit(wd, "Black", 108, 760), INK, shadow=0), 540, 1262, scale=pop(q), alpha=min(1, q * 3) * (1 - pout))


def fx_cta(cv, lt, d, p, i):
    """上に手書きの締め文字と星、胸の前を過去作のスクショが回る（1枚の幅190px）"""
    out = clamp((d - lt) / 0.25)
    s1, s2 = p["lines"]
    z1, z2 = fit(s1, "hand", 70, 700), fit(s2, "hand", 104, 760)
    n1, n2 = int(clamp((lt - 0.15) / 0.3) * len(s1)), int(clamp((lt - 0.5) / 0.45) * len(s2))
    if n1:
        put(cv, text_sprite(s1[:n1], "hand", z1), 540 - text_sprite(s1, "hand", z1).width / 2, 268, alpha=out, anchor="l")
    if n2:
        put(cv, text_sprite(s2[:n2], "hand", z2), 540 - text_sprite(s2, "hand", z2).width / 2, 372, alpha=out, anchor="l")
    for k, (x, y, s, c) in enumerate([(205, 258, 52, CREAM), (880, 420, 46, PINK), (835, 262, 28, CREAM)]):
        q = (lt - 0.75 - k * 0.12) / 0.22
        if q > 0:
            put(cv, star(s, c), x, y, scale=pop(q) * (1 + 0.08 * math.sin(lt * 6 + k)), rot=math.sin(lt * 2 + k) * 14, alpha=out)
    q0, orb = ease((lt - 0.1) / 0.4), p.get("orbit", [])
    items = [(math.sin(lt + 0.6 + k * 2 * math.pi / len(orb)), k) for k in range(len(orb))] if q0 > 0 else []
    for z, k in sorted(items):
        a = lt + 0.6 + k * 2 * math.pi / len(orb)
        put(cv, thumb(orb[k], 190, border=6), 510 + 350 * math.cos(a), 1345 + 26 * z, scale=(0.7 + 0.3 * (z + 1) / 2) * q0, alpha=(1.0 if z > 0 else 0.55) * out * q0)


FX = {"hook": fx_hook, "crayon": fx_crayon, "stock": fx_stock, "starlist": fx_starlist, "mindmap": fx_mindmap, "card_gap": fx_card_gap,
      "card_caption": fx_card_caption, "card_speed": fx_card_speed, "window": fx_window, "cta": fx_cta}


def captions(cv, t, i):
    """字幕: 行を出しっぱなしにして、いま話している語だけ色を変える"""
    c = CUTS[i]
    for cap in c.get("caps", []):
        toks, size = cap["tokens"], cap.get("size", 56)
        y = cap.get("y", 1405 if c.get("fx") == "hook" else 1192 if c.get("fx") == "cta" else 1295)
        a, b = ot(i, toks[0][1]), min(ot(i, toks[-1][2]), T0[i] + DUR[i])
        if not (a <= t < b):
            continue
        kind = "Black" if size > 60 else "Bold"
        f = font(kind, size)
        x = 520 - sum(f.getlength(s) for s, _, _ in toks) / 2
        e = clamp((t - a) / 0.08)
        for k, (s, s0, s1) in enumerate(toks):
            cur = ot(i, s0) <= t < ot(i, s1) or (k == len(toks) - 1 and t >= ot(i, s0))
            put(cv, text_sprite(s, kind, size, PINK if cur else (255, 255, 255), 0.6, 6), x - 22, y + (1 - e) * 10, alpha=e, anchor="l")
            x += f.getlength(s)


def cut_at(t):
    return max(i for i in range(len(NF)) if t >= T0[i] - 1e-6)


def compose(frame, t):
    i = cut_at(t)
    c, cv = CUTS[i], frame.convert("RGBA")
    if c.get("fx") in FX:
        FX[c["fx"]](cv, t - T0[i], DUR[i], c.get("p", {}), i)
    if c.get("fx") != "window":
        captions(cv, t, i)
    return cv.convert("RGB")


# ---------- 効果音 ----------
def synth(name):
    """効果音ファイルが無いときの仮の合成音"""
    sr, rnd = 48000, np.random.RandomState(1)
    tt = lambda dur: np.arange(int(sr * dur)) / sr
    def sweep(dur, f0, f1, dec):
        t = tt(dur)
        return np.sin(2 * np.pi * np.cumsum(f0 + (f1 - f0) * t / dur) / sr) * np.exp(-t * dec)
    def tick(amp=1.0):
        t = tt(0.03)
        return amp * (rnd.randn(len(t)) * 0.5 + np.sin(2 * np.pi * 2200 * t)) * np.exp(-t * 180)
    if name == "pop":
        y = sweep(0.18, 520, 180, 22)
    elif name == "lpop":
        y = sweep(0.09, 900, 500, 40)
    elif name == "click":
        y = tick()
    elif name == "whoosh":
        t = tt(0.45)
        y = np.convolve(rnd.randn(len(t)), np.ones(24) / 24, "same") * np.sin(np.pi * t / 0.45) ** 2 * 3
    elif name == "sparkle":
        t = tt(0.6)
        y = sum(np.where(t > k * 0.06, np.sin(2 * np.pi * fq * t) * np.exp(-(t - k * 0.06).clip(0) * 9), 0) for k, fq in enumerate((2093, 2637, 3136, 4186))) / 3
    elif name == "type":
        y = np.zeros(int(sr * 0.9))
        for k, st in enumerate((0.0, 0.11, 0.2, 0.33, 0.45, 0.56, 0.7, 0.78)):
            tk = tick(0.6 + 0.4 * (k % 2))
            y[int(st * sr):int(st * sr) + len(tk)] += tk
    else:  # notify
        y = np.concatenate([sweep(0.12, 880, 880, 14), sweep(0.2, 1320, 1320, 10)])
    path = os.path.join(WORK, f"sfx_{name}.wav")
    with wave.open(path, "wb") as wv:
        wv.setnchannels(1); wv.setsampwidth(2); wv.setframerate(sr)
        wv.writeframes((np.clip(y / (np.abs(y).max() + 1e-9) * 0.7, -1, 1) * 32767).astype(np.int16).tobytes())
    return path


@lru_cache(None)
def sfx_file(name):
    d = SPEC.get("sfx_dir")
    if d and os.path.isdir(P(d)):
        for f in sorted(os.listdir(P(d))):
            if f.lower().startswith(name + ".") or f.lower().startswith(name + "_"):
                return os.path.join(P(d), f)
    return synth(name)


def plan_sfx():
    """(出力の秒, 音, 音量, 長さ)。キラキラ系(sparkle)は starlist の3つめだけ"""
    ev = []
    add = lambda t, name, gain, dur=None: ev.append((round(t, 3), sfx_file(name), gain, dur))
    for i, c in enumerate(CUTS):
        t, fx, d = T0[i], c.get("fx"), DUR[i]
        if fx == "hook":
            for k in range(len(c["p"].get("snaps", [])[:4])):
                add(t + 0.08 + k * 0.13, "lpop", 0.32)
            add(t + 0.2, "pop", 0.4); add(t + 0.95, "type", 0.3, 0.75)
        elif fx == "crayon":
            add(t, "type", 0.22, 0.45); add(t + 0.45, "lpop", 0.34)
        elif fx == "stock":
            for k in range(3):
                add(t + 0.04 + k * 0.1, "lpop", 0.34)
            for tf in stock_fly(d):
                add(t + tf + 0.26, "pop", 0.4)
        elif fx == "starlist":
            for k, (n, g, du) in enumerate([("pop", 0.42, None), ("whoosh", 0.3, 0.5), ("sparkle", 0.24, 0.6)][:len(c["p"]["items"])]):
                add(t + 0.12 + k * 0.24, n, g, du)
        elif fx == "mindmap":
            add(t, "pop", 0.4)
            for k in range(4):
                add(t + 0.42 + k * 0.1, "lpop", 0.32)
        elif fx in ("card_gap", "card_caption", "card_speed"):
            add(t, "whoosh", 0.26, 0.5); add(t + min({"card_gap": 1.2, "card_caption": 0.5, "card_speed": 1.0}[fx], d - 0.2), "click", 0.5)
        elif fx == "window":
            add(t, "whoosh", 0.34, 0.6); add(ot(i, c["p"]["big"][1]), "pop", 0.45)
        elif fx == "cta":
            add(t + 0.15, "type", 0.25, 0.8); add(t + 0.75, "lpop", 0.34); add(t + 1.6, "notify", 0.35)
    return [e for e in ev if e[0] < TOTAL - 0.05]


# ---------- 入出力 ----------
def src_frame_raw(s):
    raw = subprocess.run(["ffmpeg", "-v", "error", "-ss", f"{s:.3f}", "-i", SRC, "-frames:v", "1", "-vf", NORM, "-f", "rawvideo", "-pix_fmt", "rgb24", "-"], capture_output=True).stdout
    return Image.frombytes("RGB", (W, H), raw)


def src_frame(t):
    i = cut_at(t)
    cw, ch, x0, y0 = ZOOM[i]
    return src_frame_raw(SEG[i][0] + (t - T0[i]) * SPEED).crop((x0, y0, x0 + cw, y0 + ch)).resize((W, H), Image.LANCZOS)


def measure():
    """人物マスク(u2net_human_seg.onnx)から各カットの head=[頭のてっぺんy, 顔の中心x, 髪の幅] を測る"""
    import onnxruntime as ort
    sess = ort.InferenceSession(P(SPEC.get("matte_model", "u2net_human_seg.onnx")), providers=["CPUExecutionProvider"])
    for i, (a, b) in enumerate(SEG):
        rows = []
        for fr in (0.15, 0.5, 0.85):
            im = src_frame_raw(a + (b - a) * fr)
            x = ((np.asarray(im.resize((320, 320))).astype(np.float32) / 255 - [0.485, 0.456, 0.406]) / [0.229, 0.224, 0.225]).transpose(2, 0, 1)[None].astype(np.float32)
            y = sess.run(None, {sess.get_inputs()[0].name: x})[0][0, 0]
            m = np.asarray(Image.fromarray(((y - y.min()) / (y.max() - y.min() + 1e-6) * 255).astype(np.uint8)).resize((270, 480))) > 128
            run = lambda yy: max(np.split(np.where(m[yy])[0], np.where(np.diff(np.where(m[yy])[0]) > 1)[0] + 1), key=len)
            top = next((yy for yy in range(480) if m[yy].sum() >= 22 and len(run(yy)) >= 22), None)   # 上げた手や指は幅が狭いので飛ばす
            if top is not None:
                r = run(min(top + 45, 479))
                rows.append((top * 4, int(r.mean() * 4), len(r) * 4))
        print(i, '"head":', [int(np.median([r[k] for r in rows])) for k in range(3)] if rows else None, rows)


def render():
    out = P(SPEC.get("out", "reel.mp4"))
    vin, vf, af = [], [], []
    for k, (s, e) in enumerate(SEG):   # カットごとに -ss で入力を分ける（1入力を trim で分けるとメモリが溢れて途中で止まる）
        vin += ["-ss", f"{s:.4f}", "-t", f"{e - s + 0.2:.4f}", "-i", SRC]
        cw, ch, x0, y0 = ZOOM[k]
        vf.append(f"[{k}:v]{NORM},crop={cw}:{ch}:{x0}:{y0},scale={W}:{H}:flags=lanczos,setpts=(PTS-STARTPTS)/{SPEED},fps={FPS},trim=end_frame={NF[k]},setpts=PTS-STARTPTS[v{k}]")
        af.append(f"[0:a]atrim={s:.4f}:{e:.4f},asetpts=PTS-STARTPTS,afade=t=in:d=0.012,afade=t=out:st={e - s - 0.012:.4f}:d=0.012,atempo={SPEED},apad,atrim=0:{NF[k] / FPS:.5f}[a{k}]")
    n = len(SEG)
    vf.append("".join(f"[v{k}]" for k in range(n)) + f"concat=n={n}:v=1:a=0[v]")
    tmp = os.path.join(WORK, "video_tmp.mp4")
    dec = subprocess.Popen(["ffmpeg", "-v", "error"] + vin + ["-filter_complex", ";".join(vf), "-map", "[v]", "-f", "rawvideo", "-pix_fmt", "rgb24", "-"], stdout=subprocess.PIPE, bufsize=W * H * 12)
    enc = subprocess.Popen(["ffmpeg", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-", "-c:v", "libx264", "-crf", "17", "-preset", "veryfast",
                            "-pix_fmt", "yuv420p", "-colorspace", "bt709", "-color_primaries", "bt709", "-color_trc", "bt709", tmp], stdin=subprocess.PIPE)
    k = 0
    while True:
        raw = dec.stdout.read(W * H * 3)
        if len(raw) < W * H * 3:
            break
        enc.stdin.write(compose(Image.frombytes("RGB", (W, H), raw), k / FPS).tobytes())
        k += 1
    enc.stdin.close()
    assert enc.wait() == 0 and k == sum(NF), f"コマ数が合わない: {k} / {sum(NF)}"
    # 音: 声は長さいっぱいまで無音で埋めてから混ぜる（amix を duration=first にすると最後の声が消えることがある）
    ins, mix = ["-i", SRC], ["[vo]"]
    af.append("".join(f"[a{j}]" for j in range(n)) + f"concat=n={n}:v=0:a=1,highpass=f=70,loudnorm=I=-15:TP=-1.5:LRA=11,apad=whole_dur={TOTAL:.4f}[vo]")
    for j, (t, f, g, dur) in enumerate(plan_sfx()):
        ins += ["-i", f]
        tr = f"atrim=0:{dur},afade=t=out:st={max(dur - 0.15, 0):.3f}:d=0.15," if dur else ""
        af.append(f"[{j + 1}:a]{tr}aformat=sample_rates=48000:channel_layouts=mono,volume={g},adelay={int(t * 1000)}:all=1[s{j}]")
        mix.append(f"[s{j}]")
    af.append("".join(mix) + f"amix=inputs={len(mix)}:normalize=0:duration=longest,alimiter=limit=0.95[out]")
    am = os.path.join(WORK, "audio_mix.m4a")
    assert subprocess.run(["ffmpeg", "-v", "error", "-y"] + ins + ["-filter_complex", ";".join(af), "-map", "[out]", "-t", f"{TOTAL:.4f}", "-ar", "48000", "-c:a", "aac", "-b:a", "192k", am]).returncode == 0
    assert subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", tmp, "-i", am, "-map", "0:v", "-map", "1:a", "-c", "copy", "-movflags", "+faststart", out]).returncode == 0
    dur = lambda st: float(subprocess.run(["ffprobe", "-v", "error", "-select_streams", st, "-show_entries", "stream=duration", "-of", "csv=p=0", out], capture_output=True, text=True).stdout.strip())
    assert abs(dur("v:0") - dur("a:0")) < 0.1, "映像と音の長さが違う"
    print("done", out, f"{TOTAL:.2f}s")


if __name__ == "__main__":
    mode = sys.argv[1]
    if mode == "info":
        print("cut starts", [round(x, 2) for x in T0], "total", round(TOTAL, 2), "\nzoom", ZOOM)
    elif mode == "measure":
        measure()
    elif mode == "stills":
        for ts in sys.argv[3:]:
            compose(src_frame(float(ts)), float(ts)).save(os.path.join(WORK, f"still_{float(ts):05.2f}.jpg"), quality=88)
    elif mode == "render":
        render()
